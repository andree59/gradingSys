// document.getElementById(postGrade).addEventListener("click", postGrade);
// document.getElementById(getaverage).addEventListener("click", getaverage);

// document.getElementById('getGrade').onclick = function(){
// function getgrades() {
//   document.getElementById('onClick').innerHTML;
// }

// this is for a letter grade from input grade0
// document.getElementById("getgrades").addEventListener("click", getGrades);
function getAverage(){
  var grade1 = parseInt(document.getElementById("grade1").value);//  for the avg input
  var grade2 = parseInt(document.getElementById("grade2").value);//for the avg input
  var grade3 = parseInt(document.getElementById("grade3").value);//for the avg input
  var total = (grade1 + grade2 + grade3)/3;

    // if (total>=90 && total<=100) {
    //   window.alert((total) + ("...") + ("You have an A"));
    // } else if (total>=80 && total<=89) {
    //     window.alert((total + ("...")+ "You have a B"));
    //   }  else if (total>=70 && total<=79) {
    //       window.alert((total + ("...") + "You have a C"));
    //     } else if (total>=60 && total<=69) {
    //          window.alert((total + ("...") + "You have a D"));
    //        } else if (total>=0 && total<=59) {
    //              window.alert((total)//;
    //            }
  // alert (total);
  if (grade1>=90 && grade1<=100) {
  document.getElementById("letter1");
  alert("Your first grade is an A");
  }
  else if (grade1>=80 && grade1<=89) {
  document.getElementById("letter1");
  alert("Your first grade is a B");
  }
  else if (grade1>=70 && grade1<=79) {
  document.getElementById("letter1");
  alert("Your first grade is a C");
  }
  else if (grade1>=60 && grade1<=69) {
  document.getElementById("letter1");
  alert("Your first grade is a D");
  }
  else if (grade2>=0 && grade2<=59) {
  document.getElementById("letter2");
  alert("Your first grade is an F");
  }
          if (grade2>=90 && grade2<=100) {
      document.getElementById("letter2");
      alert("Your second grade is an A");
      }
      else if (grade2>=80 && grade2<=89) {
      document.getElementById("letter2");
      alert("Your second grade is an B");
      }
      else if (grade2>=70 && grade2<=79) {
      document.getElementById("letter2");
      alert ("Your second grade is a C");
      }
      else if (grade2>=60 && grade2<=69) {
      document.getElementById("letter2");
      alert ("Your second grade is a D");
      }
      else if (grade3>=0 && grade3<=59) {
      document.getElementById("letter3") ;
      alert ("Your second grade is an F");
      }
        if (grade3>=90 && grade3<=100) {
          document.getElementById("letter3");
          alert("Your third grade is an A");
          }
          else if (grade3>=80 && grade3<=89) {
          document.getElementById("letter3") ;
          alert("Your third grade is a B");
          }
          else if (3>=70 && grade3<=79) {
          document.getElementById("letter3") ;
          alert ("Your third grade is a C");
          }
          else if (grade3>=60 && grade3<=69) {
          document.getElementById("letter3") ;
          alert("Your third grade is a D");
          }
          else if (grade3>=0 && grade3<=59) {
          document.getElementById("letter3");
          alert ("Your third grade is an F");
          }
alert(total) + ("this is your Average of All your grades");
          }




 // alert(total);
// }
  //if (grade1>=0 && grade1<=100, grade2>=0 && grade2<=100, grade3>=0 && grade3<=100);{

    // if grade1>=90 && grade1<=100) {
    // //document.getElementById("postGrade").innerHTML = "You got a A";
    // console.log("You have an A");
    // }
    // else if (grade1>=80 && grade1<=89) {
    // //document.getElementById("postGrade").innerHTML = "You got a B";
    // console.log("You have a B");
    // }
    // else if (grade1>=70 && grade1<=79) {
    // //document.getElementById("postGrade").innerHTML = "You got a C";
    // alert ("You have a C");
    // }
    // else if (grade1>=60 && grade1<=69) {
    // //document.getElementById("postGrade").innerHTML = "You got a D";
    // alert ("You have a D");
    // }
    // else if (grade1>=0 && grade1<=59) {
//     //document.getElementById("postGrade").innerHTML = "You need a Tutor";
//     alert ("You need a Tutor !");
//   }
// );
// }


    // this is for getting the averages
//     else if (grade2>=90 && grade2<=100) {
//     //document.getElementById("postGrade").innerHTML = "You got a A";
//     alert ("You have an A");
//     }
//     else if (grade2>=80 && grade2<=89) {
//     //document.getElementById("postGrade").innerHTML = "You got a B";
//     alert ("You have a B");
//     }
//     else if (grade2>=70 && grade2<=79) {
//     //document.getElementById("postGrade").innerHTML = "You got a C";
//     alert ("You have a C");
//     }
//     else if (grade2>=60 && grade2<=69) {
//     //document.getElementById("postGrade").innerHTML = "You got a D";
//     alert ("You have a D");
//     }
//     else if (grade2>=0 && grade2<=59) {
//     //document.getElementById("postGrade").innerHTML = "You need a Tutor";
//     alert ("You need a Tutor !");
//     }
//
//     else if (grade3>=90 && grade3<=100) {
//     //document.getElementById("postGrade").innerHTML = "You got a A";
//     alert ("You have an A");
//     }
//     else if (grade3>=80 && grade3<=89) {
//     //document.getElementById("postGrade").innerHTML = "You got a B";
//     alert ("You have a B");
//     }
//     else if (grade3>=70 && grade3<=79) {
//     //document.getElementById("postGrade").innerHTML = "You got a C";
//     alert ("You have a C");
//     }
//     else if (grade3>=60 && grade3<=69) {
//     //document.getElementById("postGrade").innerHTML = "You got a D";
//     alert ("You have a D");
//     }
//     else if (grade3>=0 && grade3<=59) {
//     //document.getElementById("postGrade").innerHTML = "You need a Tutor";
//     alert ("You need a Tutor !");
//     });
//   //}
// }
//
// // function getAverage(){
//   //var grade0 = document.getElementById("grade0").value; //this is the first input box
//   // var grade1 = document.getElementById("grade1").value;//  for the avg input
//   // var grade2 = document.getElementById("grade2").value;//for the avg input
//   // var grade3 = document.getElementById("grade3").value;//for the avg input
//   //  var getaverage = [("grade1" + "grade2" + "grade3")/3];
//
// //   if (grade1>=90 && grade1<=100) {
// // //document.getElementById("postGrade").innerHTML = "You got a A";
// // console.log("You have an A");
// // }
// // else if (grade1>=80 && grade1<=89) {
// // //document.getElementById("postGrade").innerHTML = "You got a B";
// // console.log("You have a B");
// // }
// // else if (grade1>=70 && grade1<=79) {
// // //document.getElementById("postGrade").innerHTML = "You got a C";
// // alert ("You have a C");
// // }
// // else if (grade1>=60 && grade1<=69) {
// // //document.getElementById("postGrade").innerHTML = "You got a D";
// // alert ("You have a D");
// // }
// // else if (grade1>=0 && grade1<=59) {
// // //document.getElementById("postGrade").innerHTML = "You need a Tutor";
// // alert ("You need a Tutor !");
// // }
// // }
// // // this is for getting the averages
// // if (grade2>=90 && grade2<=100) {
// // //document.getElementById("postGrade").innerHTML = "You got a A";
// // alert ("You have an A");
// // }
// // else if (grade2>=80 && grade2<=89) {
// // //document.getElementById("postGrade").innerHTML = "You got a B";
// // alert ("You have a B");
// }
// else if (grade2>=70 && grade2<=79) {
// //document.getElementById("postGrade").innerHTML = "You got a C";
// alert ("You have a C");
// }
// else if (grade2>=60 && grade2<=69) {
// //document.getElementById("postGrade").innerHTML = "You got a D";
// alert ("You have a D");
// }
// else if (grade2>=0 && grade2<=59) {
// //document.getElementById("postGrade").innerHTML = "You need a Tutor";
// alert ("You need a Tutor !");
// }
//
// if (grade3>=90 && grade3<=100) {
// //document.getElementById("postGrade").innerHTML = "You got a A";
// alert ("You have an A");
// }
// else if (grade3>=80 && grade3<=89) {
// //document.getElementById("postGrade").innerHTML = "You got a B";
// alert ("You have a B");
// }
// else if (grade3>=70 && grade3<=79) {
// //document.getElementById("postGrade").innerHTML = "You got a C";
// alert ("You have a C");
// }
// else if (grade3>=60 && grade3<=69) {
// //document.getElementById("postGrade").innerHTML = "You got a D";
// alert ("You have a D");
// }
// else if (grade3>=0 && grade3<=59) {
// //document.getElementById("postGrade").innerHTML = "You need a Tutor";
// alert ("You need a Tutor !");
// }
//
//
// // document.getElementById("getaverage").addEventListener("click", getAverage);
//
// // function getAverage(){
// //   var grade1 = parseInt(document.getElementById("grade1").value);//  for the avg input
// //   var grade2 = parseInt(document.getElementById("grade2").value);//for the avg input
// //   var grade3 = parseInt(document.getElementById("grade3").value);//for the avg input
// //   var total = (grade1 + grade2 + grade3)/3;
// //
// //   //if (grade1>=0 && grade1<=100, grade2>=0 && grade2<=100, grade3>=0 && grade3<=100);{
// //
// //       alert(total);
// //   //}
// // }
//


  //      if (grade1>=90 && grade1<=100) {
  //   //document.getElementById("postGrade").innerHTML = "You got a A";
  //   alert ("You have an A");
  // }
  // else if (grade1>=80 && grade1<=89) {
  //   //document.getElementById("postGrade").innerHTML = "You got a B";
  //   alert ("You have a B");
  // }
  // else if (grade1>=70 && grade1<=79) {
  //   //document.getElementById("postGrade").innerHTML = "You got a C";
  //   alert ("You have a C");
  // }
  // else if (grade1>=60 && grade1<=69) {
  //   //document.getElementById("postGrade").innerHTML = "You got a D";
  //   alert ("You have a D");
  // }
  // else if (grade1>=0 && grade1<=59) {
  //   //document.getElementById("postGrade").innerHTML = "You need a Tutor";
  //   alert ("You need a Tutor !");
  // }
  // // else if (grade1>=101) {
  // //   document.getElementById("postGrade").innerHTML = "Sorry, but you must enter a number between 1 and 100";
  // // }


       //if (grade2>=90 && grade2<=100) {
    //document.getElementById("postGrade").innerHTML = "You got a A";
  //  alert ("You have an A");
   //}
   //else if (grade2>=80 && grade2<=89) {
     //document.getElementById("postGrade").innerHTML = "You got a B";
    // alert ("You have a B");
   //}
   //else if (grade2>=70 && grade2<=79) {
     //document.getElementById("postGrade").innerHTML = "You got a C";
     //alert ("You have a C");
   //}
   //else if (grade2>=60 && grade2<=69) {
     //document.getElementById("postGrade").innerHTML = "You got a D";
     //alert ("You have a D");
   //}
  // else if (grade2>=0 && grade2<=59) {
  //   //document.getElementById("postGrade").innerHTML = "You need a Tutor";
     //alert ("You need a Tutor !");
  // }
  //  else if (grade2>=101) {
  //    document.getElementById("postGrade").innerHTML = "Sorry, but you must enter a number between 1 and 100";
  //  }

        //if (grade3>=90 && grade3<=100) {
     //document.getElementById("postGrade").innerHTML = "You got a A";
    // alert ("You have an A");
   //}
   //else if (grade3>=80 && grade3<=89) {
     //document.getElementById("postGrade").innerHTML = "You got a B";
  //    alert ("You have a B");
  //  }
  //  else if (grade3>=70 && grade3<=79) {
  //    //document.getElementById("postGrade").innerHTML = "You got a C";
  //    alert ("You have a C");
  //  }
  //  else if (grade3>=60 && grade3<=69) {
  //    //document.getElementById("postGrade").innerHTML = "You got a D";
  //    alert ("You have a D");
  //  }
  //  else if (grade3>=0 && grade3<59) {
  //    alert ("You need a Tutor !");
  //  }
  //  else if (grade3>=101) {
  //    document.getElementById("postGrade").innerHTML = "Sorry, but you must enter a number between 1 and 100";
  //  }



// var getaverage=(grade1 + grade2 + grade3)/3;
// // for (var i=0;i<getaverage.length; i++)
//
// }
// // var grade1=document.getElementById("grade1").value;
// // var grade2=document.getElementById("grade2").value;
// // var grade3=document.getElementById("grade3").value;
// //
// // function getAverage(grade1,grade2,grade3) {
// //   var ans = (grade1 + grade3 + grade3)/3;
// //     console.log(ans);
// //   }
//   // var total=document.getElementById("grade1"+"grade2"+"grade3"/3);
//   // document.getElementById("postAverage").innerHTML = "Your Average is";
//
//
//     //   numAvg = getAverage(grade1, grade2,grade3)/3;
//     // console.log(numAvg);
//
//
// //document.getElementById("postAverage").innerHTML = "Your average is" + "";
//
//   // console.log(grade1 + grade2 + grade3)/3;
//
//
//
//
//
//
//
//
//
//
//
// // let myGrade = "A";
// // if (90=<100)
// // let myGrade = "B";
// // if else  (80=<89)
// // let myGrade = "C";
// // if else (70=>79)
// // let myGrade = "D";
// // if else(60=>69)
// // let myGrade = "F";
// // if else(59>0)
// // console.log(myGrade);
// // function myGrade(){}
//
// // average(0<100). average
// // average([1]) #1.0
// // average([0,2]) #1.0
// // average([1,2]) #1.5
// // function changeText(form) {
// //   id.innerHTML = "Ooops !, Please enter a number between 0 and 100.";
//
// //if (input type="100<") {
// //  alert("Please enter a number between 0 and 100")
// // if onclick=" ":
//
//
//
//
// // // function mynumberGrade() {
// // //   document.getElementbyName("grade").innerHTML = " ";
// // var content = document.getElementById("grade");
// // var button = document.getElementById("myletterGrade");
// //
// // function addListeners(){
// //   if(window.addEventListener) {
// //       document.getElementById ('myletterGrade').addEventListener(
// //         "click",letterGrade, false);
// //   } else if (window.attachEvent){}
// //
// // function letterGrade(){
// //
// //   alert (this.id+" you have an a");
// // }
// // window.onload = addListeners;
// //
// // var = 0 <= 100;
// // function letterGrade(){
// //     if("90 <= 100"){
// //       alert("You have an "A"");
// //     } else  {
// //       myletterGrade == "80 <= 89"{
// //          alert ("You have a "B"");
// //
// //        } else  {
// //          myletterGrade == "70 <= 79"{
// //             alert ("You have a "C"");
// //
// //           } else  {
// //             myletterGrade == "60 <= 69"{
// //                alert ("You have a "D"");
// //
// //              } else {
// //                myletterGrade == "0 <= 59"{
// //                   alert ("You need a Tutor");
// //                 }
//
// //   var letterGrade = ("90 <= 100");
// //   var letterGrade1 = ("80 <= 89");
// //   var letterGrade2 = ("70 <= 79");
// //   var letterGrade3 = ("60 <= 69");
// //   var letterGrade4 = ("50 <= 59");
// //   var letterGrade5 =  ("0 <= 49"):
// //   document.getElementById("grade").innerHTML= letterGrade, letterGrade1;letterGrade2,
// //   letterGrade3, letterGrade4, letterGrade5;
// // }
//
// //   if (letterGrade =="90 <= 100") {
// //   // var x = document.getElementsByName("mynumberGrade");
// //   // document.getElementById("onclick").innerHTML = "mynumberGrade" + letterGrade;
// //
// //     alert("You have an "A"");
// //
// //   } else if {(letterGrade == "80 <= 89")
// //     alert ("You have a "B"");
// //
// //     } else if (letterGrade == " 70 <= 79")
// //       alert ("You have a "C"");
// //
// //       } else if (letterGrade == "60 <= 69")
// //         alert ("You have a "D"");
// //
// //         } else if (letterGrade == "0 <= 59")
// //           alert ("You need a Tutor");
// //
// //  }
// //
// // }
// //
//
// // function myaverageGrade = (){
// //   let myaverageGrade = ["A" + "B" + "C" + "D" + "F"/divided by how many entires];
// //   console.log(myaverageGrade);
// // }
// // myaverageGrade();
// // mynumberGrade ();
// // addEventListener("click",
// //   function() {
// //     alert("click");
// //
// //
// //     // function myFunction(){
// //     //     document.getElementById("pf").innerHTML="A";
// //     // }
// //
// // var n = prompt("Enter")
// //
// //
// // let id1 = mynumberGrade [0]; //between 0>100
// // let id2 = mynumberGrade [1]; //between 0>100
// // let id3 = mynumberGrade [2]; //between 0>100
// // let id4 = mynumberGrade [3]; //between 0>100
// // let id5 = mynumberGrade [4]; //between 0>100
// //
// //   }
// // mynumberGrade.length;//5
// // let myletterGrade = ["A", "B", "C","D","F"];
// // let id1 = myletterGrade [0];//a
// // let id2 = myletterGrade [1];//b
// // let id3 = myletterGrade [2];//c
// // let id4 = myletterGrade [3];//d
// // let id5 = myletterGrade [4];//f
// //
// // console.log('myletterGrade'+ "." + "text");
// // addEventListener("click",
// //   function() {
// //     alert("click");
// //   }
// // function myFunction(){
// //   var avergeNumbers = 0;
// //   var averageL= 0;
// //   var averageNumbergrade = 0;
// //   var averageLettergrade = 0;
// //   var wildCh = 0;
// //
// // for(var i = 0; i <= x.length; i++){
// //   if(x[i] == " "){
// //   spaceCounter++;
// //   wordCounter++;
// //
// //   if( x[i] == "." || x[i] == "?" || x[i] == "!"){
// //     sentenceCounter++;
// //   }
// // }
// // avergeNumbergrade = numberAdd/numberentry;
// // document.getElementById('id1').innerHTML = "You have an A" + avergeNumbergrade;
// // document.getElementById('id2').innerHTML = "You have a B" + avergeNumbergrade;
// // document.getElementById('id3').innerHTML = "You have a C" + averageNumbergrade;
// // document.getElementById('id4').innerHTML = "You have a D" + averageNumbergrade;
// // document.getElementById('id5').innerHTML = "You have an F" + averageNumbergrade;
